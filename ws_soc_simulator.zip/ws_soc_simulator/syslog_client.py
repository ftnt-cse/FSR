#!/usr/bin/env python3
from soc_simulator.artifact_factory import *
from soc_simulator.fortisoar_lib import *
from soc_simulator.main_lib import *

event = '''2021-05-17T07:13:53Z Win2019DC 10.222.248.63 AccelOps-WUA-WinLog-Microsoft-Windows-Sysmon/Operational [phCustId]="2000" [customer]="fortielab" [monitorStatus]="Success" [Locale]="en-US" [MachineGuid]="bb6fbec5-6b2b-4378-82d4-bda8fedfd91b" [timeZone]="+0100" [eventName]="Microsoft-Windows-Sysmon/Operational" [eventSource]="Microsoft-Windows-Sysmon" [eventId]="11" [eventType]="Information" [domain]="NT AUTHORITY" [computer]="Win2019DC.fortielab.com" [user]="SYSTEM" [userSID]="S-1-5-18" [userSIDAcctType]="User" [eventTime]="May 17 2021 07:13:52" [deviceTime]="May 17 2021 07:13:52" [msg]="File created:
RuleName: Downloads
UtcTime: 2021-05-17 07:13:52.792
ProcessGuid: {bb6fbec5-17b0-60a2-4723-000000001200}
ProcessId: 7232
Image: C:\\Program Files\\NAILI\\Brave-Browser\\Application\\brave.exe
TargetFilename: C:\\Users\\Administrator\\Downloads\\39582b (1).pdf:Zone.Identifier
CreationUtcTime: 2021-05-17 07:13:52.116"'''

if os.getuid() == 0:
    send_event("10.0.1.6","10.0.1.5",event)
