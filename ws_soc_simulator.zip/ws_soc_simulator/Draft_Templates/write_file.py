import base64
file={{vars.file_attachements.0.file}}
filename={{vars.file_attachements.0.metadata.filename}}
try:
	with open('/tmp/'+filename, 'wb') as tmp_file:
		tmp_file.write(base64.b64decode(file))
except:
	print('Generic: Could not write attachment!')