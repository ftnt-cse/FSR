#!/bin/bash
git commit -m"_$1" && git push -u origin master
