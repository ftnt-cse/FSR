#encoding=utf8
""" Copyright start
  Copyright (C) 2008 - 2020 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end """
import json
import os
import requests
import time
import logging
import shutil
import configparser
import uuid
import datetime
from os.path import join, dirname, abspath
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from logging.handlers import RotatingFileHandler
from cshmac.requests import HmacAuth
from requests_toolbelt import MultipartEncoder
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


config = configparser.ConfigParser()
conf_path = join(dirname(abspath(__file__)), 'setup.conf')
config.read(conf_path)
MAIN_URL = 'https://' + config['DEFAULT']['MAIN_URL']
APPLIANCE_PATH = config['DEFAULT']['APPLIANCE_PATH']
LOG_DIR = config['DEFAULT']['LOG_DIR']
LOG_FILE_PATH = join(LOG_DIR, 'sample_data.log')

formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
handler = RotatingFileHandler(LOG_FILE_PATH, maxBytes=5 * 1024 * 1024, backupCount=10)
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel('INFO')

APPLIANCE_PUBLIC_KEY = ''
APPLIANCE_PRIVATE_KEY = ''
PUBLISH = '/api/publish'
FILE_EP = '/api/3/files'
IMPORT_JOB = '/api/3/import_jobs'
IMPORT = '/api/import/'
WIDGET = '/api/3/install/widget'

def read_files(key_path):
    global APPLIANCE_PUBLIC_KEY
    global APPLIANCE_PRIVATE_KEY
    try:
        with open(join(key_path, 'APPLIANCE_PRIVATE_KEY'), 'r') as private:
            APPLIANCE_PRIVATE_KEY = private.read().strip()
        with open(join(key_path, 'APPLIANCE_PUBLIC_KEY'), 'r') as public:
            APPLIANCE_PUBLIC_KEY = public.read().strip()
    except FileNotFoundError:
        src = APPLIANCE_PATH
        shutil.copy(join(src, 'APPLIANCE_PRIVATE_KEY'), key_path)
        shutil.copy(join(src, 'APPLIANCE_PUBLIC_KEY'), key_path)
        read_files(key_path)


def get_appliance_keys():
    key_path = join(os.path.dirname(os.path.abspath(__file__)), 'keys')
    read_files(key_path)



def make_request(url, method,headers=None ,body=None,files=None,params=None):
    try:
        #pdb.set_trace()
        bodyless_methods = ['head', 'get']
        if method.lower() in bodyless_methods:
            body = None
        if files:
            auth = HmacAuth(url, method,APPLIANCE_PUBLIC_KEY,APPLIANCE_PRIVATE_KEY,APPLIANCE_PUBLIC_KEY.encode('utf-8'))
            response = requests.request(method,url,auth=auth,files=files,verify=False,headers=headers)
        else:
            body_payload = json.dumps(body) if body else APPLIANCE_PUBLIC_KEY
            auth = HmacAuth(url, method, APPLIANCE_PUBLIC_KEY, APPLIANCE_PRIVATE_KEY,body_payload)
            response = requests.request(method, url, auth=auth, json=body,verify=False)
        if response.status_code == 200 or response.status_code == 201 or response.status_code == 204:
            return response.json()
        elif response.status_code == 503:
            return response.json()
        elif response.status_code >= 400:
            print(response.json())
    except Exception as Err:
        print('Exception occurred: {}'.format(str(Err)))
        return False


def upload_file(data_path):
    file = open(data_path,'rb')
    file_name = data_path.split("/")[-1] 
    url = MAIN_URL + FILE_EP
    multipart_headers = {'Expire': 0}
    request_headers = {}
    extra_fields = {}
    files = {'file': (file_name, file,'application/json', multipart_headers)}
    response = make_request(url,'POST',files=files,headers=request_headers)
    return response.get('@id')


def create_import_job(file_iri):
   url = MAIN_URL + IMPORT_JOB
   #payload = {"file" : {"@id":file_iri},"status":"Draft","options":{}}
   payload = {"file" : file_iri,"status":"Draft","options": {}}
   response = make_request(url,'POST',body=payload)
   job_id = response.get('@id').split("/")[-1]
   return job_id

def populate_import_options(import_job_id):
   url = MAIN_URL + IMPORT + import_job_id.split("/")[-1]
   response = make_request(url,'GET')
   if response.get('status').get('result') == "Import job options populated" :
       return True
   else:
       exit()

def check_option_and_setup_job(import_job_id):
   url = MAIN_URL + IMPORT_JOB +'/'+ import_job_id +'?__selectFields=errorMessage,status,progressPercent,file,options'
   response = make_request(url,'GET')
   options = response
   job_url = MAIN_URL + IMPORT_JOB +"/"+ import_job_id
   response = make_request(url,'PUT',body=options)
   if response:
       import_url = MAIN_URL + IMPORT + import_job_id
       
       headers = {"Content-Type":"application/json"} 
       body=None
       response2 = make_request(import_url,'PUT',body=body,headers=headers)

def check_import_progress(import_job_id):
   url = MAIN_URL + IMPORT_JOB +'/'+ import_job_id +'?__selectFields=errorMessage,status,progressPercent'
   while True:
       response = make_request(url,'GET')
       logger.info(response)
       if response.get('status') == 'Import Complete':
           return True
       elif response.get('errorMessage') :
           logger.info("Publish Failed")
           print("import failed")
           return False
       else:
           time.sleep(10) 

def add_widget(data_path):
    widget_url = MAIN_URL + WIDGET
    with open(data_path,'r') as fp:
        body = json.load(fp)
        for item in body['widgets']:
            widget = make_request(widget_url, 'POST', body=item)


def trigger_playbook(main_url, payload=None):
    response = make_request(main_url, 'POST', body=APPLIANCE_PUBLIC_KEY)
    logger.info('Response for trigger playbook: {}'.format(response))
    poll_url = MAIN_URL + '/api/wf/api/workflows/?task_id={task_id}&fields=status&parent__isnull=True'.format(task_id=response["task_id"])
    current_time = datetime.datetime.now()
    max_wait_time = current_time + datetime.timedelta(minutes=10)
    while datetime.datetime.now() < max_wait_time:
        ret = make_request(poll_url, 'GET')
        hydra_member = ret.get("hydra:member")
        if len(hydra_member) == 0:
            time.sleep(20)
        elif ('status' in hydra_member[0] and hydra_member[0]['status'] == 'active') or ('status' in hydra_member[0] and hydra_member[0]['status'] == 'incipient'):
            time.sleep(30)
        else:
            logger.info("Playbook execution completed: {}".format(hydra_member[0]))
            return

def main():
    get_appliance_keys()
    data_path =  join(dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
    file_iri = upload_file(data_path+"/Content_Pack.json")
    import_job_id =create_import_job(file_iri)
    result =  populate_import_options(import_job_id)
    time.sleep(10)
    if result:
        check_option_and_setup_job(import_job_id)
    ret = check_import_progress(import_job_id)
    if ret:
        add_widget(data_path+"/Widget-01-EWL.json")
        endpoint = 'demo_records'
        url = MAIN_URL + '/api/triggers/1/' + endpoint
        trigger_playbook(url)
    
  


if __name__ == "__main__":
    main()