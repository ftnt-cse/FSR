#!/bin/sh
# Copyright start
# Copyright (C) 2008 - 2020 Fortinet Inc.
# All rights reserved.
# FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
# Copyright end

get_elastic_mode()
{

    status=$(curl -s -o /dev/null -w %{http_code}  --user elastic:$hkey -XGET 'http://localhost:9200')

    if [ $status == 200 ]
    then
        url='http://localhost:9200'
    else
        url='https://localhost:9200'
    fi
    echo $url
}

get_hkey()
{
     
    hkey=`sudo csadm license --get-hkey`
    echo $hkey
}

wait_for_service(){
   service=$1

   url=$(get_elastic_mode)
   if [ "$service" == "kibana" ]; then
      url="http://localhost:5601"
   fi
   echo "waiting for $service to start"
   NEXT_WAIT_TIME=0
   # --silent  Don't show progress meter
   local cmd="curl --silent $url"
   until $cmd > /dev/null || [ $NEXT_WAIT_TIME -eq 60 ]; do
       NEXT_WAIT_TIME=$(($NEXT_WAIT_TIME+10))
       echo "Sleep 10 seconds..."
       sleep $NEXT_WAIT_TIME
   done
   if [ $NEXT_WAIT_TIME -ge 60 ]; then
       echo "Timed out waiting for $service to start"
       exit 1
   fi
}

# start elasticsearch. it is already enabled by cyops-search
systemctl start elasticsearch

wait_for_service elasticsearch

echo "===> Adding Elastic Data"
zip_file_path=/opt/fsr-ir-content-pack/data/backups.zip
unzip -qo $zip_file_path -d /var/lib/elasticsearch/
chown -R elasticsearch:elasticsearch /var/lib/elasticsearch/backups
if grep -q "path.repo: /var/lib/elasticsearch/backups" /etc/elasticsearch/elasticsearch.yml; then
    echo "path.repo Already exisits"
else
    echo "setting path.repo"
    sed -i '/path.logs*/a path.repo: /var/lib/elasticsearch/backups' /etc/elasticsearch/elasticsearch.yml
fi

# restart services
echo ""
echo "restarting elasticsearch..."
systemctl restart elasticsearch
wait_for_service elasticsearch

hkey=$(get_hkey)
url=$(get_elastic_mode)

curl --user elastic:$hkey -X  PUT "$url/_snapshot/my_fs_backup" -H 'Content-Type: application/json' -d \
    '{
        "type": "fs",
        "settings": {
            "location": "/var/lib/elasticsearch/backups",
            "compress": true
        }
    }
    '
curl --user elastic:$hkey -X POST "$url/_snapshot/my_fs_backup/mitre_snapshot/_restore" -H 'Content-Type: application/json'
